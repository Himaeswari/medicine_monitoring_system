      	
	 MEDICINE MONITORING SYSTEM




Admin Registration:
	
	Fill all the mandatory fields and submit the datails. AdminId is generated.

Admin Login : 

	Login by using AdminId and password




Branch Admin Fetch:
	
	Fetches the branch admin details by clicking on the branch admin button.

Branch Admin Registration:
	
	Fill all the mandatory fields and submit the details.

Branch Admin Update:

	 Admin Updates the corressponding records in the table.

Branch Admin Delete:

	Admin deletes the record by clicking the delete button.




Medicine Fetch:
	
	Fetches the Medicine details by clicking on the medicine button.

Medicine Registration:
	
	Fill all the mandatory fields and submit the details.

Medicine Update:
	 
	Admin Updates the corressponding records in the table.

Medicine Delete:
	
	Admin deletes the record by clicking the delete button.



Admin Logout:
	
	Admin session is invalidated.




	Log4j is implemented.


	
	Session management is implemented.

	

	Application exceptions are handled.

	




