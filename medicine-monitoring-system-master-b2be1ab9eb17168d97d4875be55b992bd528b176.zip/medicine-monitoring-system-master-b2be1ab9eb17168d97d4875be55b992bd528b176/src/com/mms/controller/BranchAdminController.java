package com.mms.controller;

import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import com.mms.dao.ApplicationException;
import com.mms.model.BranchAdminPojo;
import com.mms.model.StatePojo;
import com.mms.service.BranchAdminService;

@Controller
public class BranchAdminController {
	public static Logger logger = Logger.getLogger("medicine-monitoring-system");

	@Autowired
	BranchAdminService branchAdminService;

//Fetching the  details of branch admin
	
	@RequestMapping(value = "/fetch", method = RequestMethod.GET)
	public ModelAndView listBranchAdmin(ModelAndView mav, HttpServletRequest request) throws ApplicationException
	{
		HttpSession session = request.getSession(false);
		String users = (String) session.getAttribute("users");

		if (users != null) 
		{
			try 
			{
				List<BranchAdminPojo> adminList = branchAdminService.fetchAdmin();

				mav.addObject("adminList", adminList);
				mav.setViewName("BranchAdminFetch");
			}

			catch (ApplicationException e)
			{
				logger.error(e);
				mav=new ModelAndView("Error");
			}
		} 
		else 
		{
			mav=new ModelAndView("Login");
		}

		return mav;

	}

//Deleting a branch admin record	
	
	@RequestMapping(value = "/delete/{id}", method = RequestMethod.GET)
	public String delete(@PathVariable("id") int id, HttpServletRequest request) throws ApplicationException
	{

		HttpSession session = request.getSession(false);
		String users = (String) session.getAttribute("users");
		if (users != null) 
		{
			try 
			{
				branchAdminService.delete(id);
			}

			catch (ApplicationException e)
			{
				logger.error(e);
				return "Error";
			}
		} 
		else
		{
			return "redirect:/login";
		}

		return "redirect:/fetch";
	}

//Redirect to add  a new branch admin	
	
	@RequestMapping(value = "/branchAdminAdd", method = RequestMethod.GET)
	public ModelAndView showRegister(HttpServletRequest request, HttpServletResponse response) throws ApplicationException 
	{
		HttpSession session = request.getSession(false);
		List<StatePojo> stateList=null;
		String users = (String) session.getAttribute("users");
		ModelAndView mav = null;
		if (users != null)
		{
			try
			{
            stateList = branchAdminService.fetchState();
			}
			catch (ApplicationException e)
			{
				logger.error(e);
				mav=new ModelAndView("Error");
			}
        
			mav = new ModelAndView("AddAdmin");
		     mav.addObject("stateList",stateList);
			mav.addObject("pojo", new BranchAdminPojo());
		} 
		else 
		{
			mav= new ModelAndView("Login");
		}

		return mav;
	}

//Add a new branch admin	
	
	@RequestMapping(value = "/branchAdminProcess", method = RequestMethod.GET)
	public String addUser(HttpServletRequest request, HttpServletResponse response,
			@ModelAttribute("pojo") BranchAdminPojo pojo, BindingResult result) throws ApplicationException 
	{
		HttpSession session = request.getSession(false);
		String users = (String) session.getAttribute("users");
		int id = 0;
		String mav = null;
		if (users != null)
		{
			try 
			{
				id = branchAdminService.addAdmin(pojo);
			} 
			catch (ApplicationException e) 
			{
				logger.error(e);
		        mav= "redirect:/error";
			}

			if (id != 0)
			{
			    mav= "redirect:/success";
			}
			else
			{
				mav="RegisterFailure";
			}
		} 
		else
		{
			mav="Login";
		}
		return mav;
	}
	
	@RequestMapping(value = "/success", method = RequestMethod.GET)
	public String success(HttpServletRequest request)
	{
		HttpSession session = request.getSession(false);
		String users = (String) session.getAttribute("users");
		String mav=null;
		if (users != null) 
		{
			mav= "redirect:/fetch";
		}
		else 
		{
			mav= "Login";
		}
		return mav;
	}

	
//Redirect to update the details
	
	@RequestMapping(value = "/update/{id}")
	public ModelAndView edit(@PathVariable int id, Model m, HttpServletRequest request) throws ApplicationException
	{
		HttpSession session = request.getSession(false);
		List<StatePojo> stateList=null;
		String users = (String) session.getAttribute("users");
		ModelAndView mav=null;
		if (users != null) 
		{
			try
			{
			BranchAdminPojo bPojo = branchAdminService.getBranchAdminId(id);
			session.setAttribute("state",bPojo.getState());
			 stateList = branchAdminService.fetchState();
			m.addAttribute("command", bPojo);
		    }
			catch (ApplicationException e) 
			{
				logger.error(e);
				mav=new ModelAndView("Error");
			}
		}
		else
		{
			mav=new ModelAndView("Login");
		}
		mav=new ModelAndView("BranchAdminEdit");
		 mav.addObject("stateList",stateList);
		return mav;
	}

//Update the details of the branch admin	
	
	@RequestMapping(value = "/updatesave", method = RequestMethod.GET)
	public String editsave(@ModelAttribute("bPojo") BranchAdminPojo bPojo, HttpServletRequest request)
			throws ApplicationException
	{
		HttpSession session = request.getSession(false);
		String users = (String) session.getAttribute("users");
		if (users != null)
		{
			try
			{
			branchAdminService.update(bPojo);
			}
		
		catch (ApplicationException e) 
		{
			logger.error(e);
			return "Error";
		}
		}
		else 
		{
			return "redirect:/login";
		}
		return "redirect:/fetch";
	}
}