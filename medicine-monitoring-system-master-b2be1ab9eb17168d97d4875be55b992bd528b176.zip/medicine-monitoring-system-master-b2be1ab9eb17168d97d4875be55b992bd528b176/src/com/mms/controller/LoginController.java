package com.mms.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.ui.ModelMap;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import com.mms.dao.ApplicationException;
import com.mms.model.AdminPojo;
import com.mms.service.AdminService;
import com.ms.validator.AdminValidator;

@Controller
public class LoginController {
	public static Logger logger = Logger.getLogger("medicine-monitoring-system");
	
	@Autowired
	AdminService adminService;
	
//Redirect to the login page
	
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public ModelAndView home(HttpServletRequest request)
	{
		return new ModelAndView("Login");
	}

	
//Validating the username and password	
	
	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public String login(@RequestParam("username") String userName, @RequestParam("password") String password,
			ModelMap map, HttpServletRequest request) throws ApplicationException
	{
		AdminPojo pojo = new AdminPojo();
		AdminValidator validator = new AdminValidator();
		int check = 0;
		
		if (validator.checkDigit(userName) == true)
		{
			int user = Integer.parseInt(userName);
			pojo.setAdminId(user);
			pojo.setPassword(password);
			String users = Integer.toString(user);
			try
			{
				check = adminService.checkAdmin(pojo);
			} 
			catch (ApplicationException e)
			{
				logger.error(e);
				return "Error";
			}

			if (check == 1)
			{
				HttpSession session = request.getSession();
				session.setAttribute("users", users);
				
				return "redirect:/options";

			}

			else if (check == 0)
			{
				map.put("message", "Invalid Password");
				String message = (String) request.getAttribute("message");

				return "Login";
			} 
			else
			{
				map.put("message", "Invalid User");
				String message = (String) request.getAttribute("message");

				return "Login";
			}
		}
		else
		{
			map.put("message", "Invalid User");
			String message = (String) request.getAttribute("message");

			return "Login";
		}

	}


	
	@RequestMapping(value = "/options", method = RequestMethod.GET)
	public ModelAndView options(HttpServletRequest request)
	{
		HttpSession session = request.getSession(false);
		String users = (String) session.getAttribute("users");
		ModelAndView mav=null;
		if (users != null) 
		{
			mav= new ModelAndView("Options");
		}
		else 
		{
			mav= new ModelAndView("Login");
		}
		return mav;

	}
	
	
	@RequestMapping(value = "/error", method = RequestMethod.GET)
	public ModelAndView error(HttpServletRequest request)
	{
		HttpSession session = request.getSession(false);
		String users = (String) session.getAttribute("users");
		ModelAndView mav=null;
		if (users != null) 
		{
			mav= new ModelAndView("Error");
		}
		else 
		{
			mav= new ModelAndView("Login");
		}
		return mav;
		
	}
	
	
	
	
//Invalidating the session and redirect to login page
	
	@RequestMapping(value = "/logout", method = RequestMethod.GET)
	public ModelAndView logout(HttpServletRequest request)
	{
		ModelAndView mav;
		HttpSession session = request.getSession(false);
		String users = (String) session.getAttribute("users");
		session.invalidate();

		mav=new ModelAndView("Login");
		return mav;
	}

	
	
	@RequestMapping(value = "/register", method = RequestMethod.GET)
	public ModelAndView showRegister(HttpServletRequest request, HttpServletResponse response)
	{
		
		ModelAndView mav;
		
			mav = new ModelAndView("register");
			mav.addObject("pojo", new AdminPojo());
		
		return mav;
	}

	
	
	@RequestMapping(value = "/registerProcess", method = RequestMethod.GET)
	public ModelAndView addUser(HttpServletRequest request, HttpServletResponse response,
			@ModelAttribute("pojo") AdminPojo pojo, BindingResult result) throws ApplicationException 
	{
		int id = 0;
		
		ModelAndView mav=null;
			try
			{
				id = adminService.add(pojo);
			}

			catch (ApplicationException e)
			{
				logger.error(e);
				mav=new ModelAndView("Error");
			}

			if (id != 0)
				mav=new ModelAndView("RegisterSuccess", "id", id);
			else
				mav=new ModelAndView("RegisterFailure");
	      return mav;
	}

}
