package com.mms.dao;

import java.util.List;

import com.mms.model.BranchAdminPojo;
import com.mms.model.StatePojo;

public interface BranchAdminDao {
	public List<BranchAdminPojo> fetchAdmin() throws ApplicationException;
	public  void delete(int id) throws ApplicationException ;
	public int addAdmin(BranchAdminPojo pojo) throws ApplicationException;
	public void update(BranchAdminPojo pojo) throws ApplicationException;
	public BranchAdminPojo getBranchAdminId(int id) throws ApplicationException;
	public List<StatePojo> fetchState() throws ApplicationException;
}
