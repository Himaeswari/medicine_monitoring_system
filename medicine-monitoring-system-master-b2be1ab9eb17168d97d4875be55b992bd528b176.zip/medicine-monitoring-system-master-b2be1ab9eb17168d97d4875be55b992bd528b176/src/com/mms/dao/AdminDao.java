package com.mms.dao;

import com.mms.model.AdminPojo;

public interface AdminDao
{
	public int checkAdmin(AdminPojo pojo) throws ApplicationException;
	public int  add(AdminPojo pojo) throws ApplicationException;
	
}
