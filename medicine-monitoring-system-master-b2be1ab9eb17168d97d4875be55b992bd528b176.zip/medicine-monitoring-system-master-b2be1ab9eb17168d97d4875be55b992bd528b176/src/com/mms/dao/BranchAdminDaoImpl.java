package com.mms.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.stereotype.Repository;

import com.mms.model.BranchAdminPojo;
import com.mms.model.StatePojo;

@Repository("branchAdminDao")
public class BranchAdminDaoImpl implements BranchAdminDao {
	
	//To fetch records from the database
	
	public List<BranchAdminPojo> fetchAdmin() throws ApplicationException {
		
		SessionFactory sf = null;
		Session session = null;
		sf = HibernateUtil.getSessionFactory();
		session = sf.openSession();
		List<BranchAdminPojo> adminList = new ArrayList<BranchAdminPojo>();
		
		
		try {
			List list = session.createQuery("from BranchAdminEntity").list();
	
			for (int i = 0; i < list.size(); i++) {
				BranchAdminEntity admin = (BranchAdminEntity) list.get(i);
				BranchAdminPojo pojo = new BranchAdminPojo();
				
				pojo.setBranchAdminId(admin.getBranchAdminId());
				pojo.setFirstName(admin.getFirstName());
				pojo.setLastName(admin.getLastName());
				pojo.setAge(admin.getAge());
				pojo.setGender(admin.getGender());
				pojo.setDob(admin.getDob());
				pojo.setContactNumber(admin.getContactNumber());
				pojo.setAlternateContactNumber(admin.getAlternateContactNumber());
				pojo.setEmailId(admin.getEmailId());
				pojo.setBranchName(admin.getBranchName());
				pojo.setAddressLine1(admin.getAddressLine1());
				pojo.setAddressLine2(admin.getAddressLine2());
				pojo.setCity(admin.getCity());
				pojo.setState(admin.getState());
				pojo.setZipCode(admin.getZipCode());

				adminList.add(pojo);
			}
		} 
		
		catch (HibernateException e) 
		{
			throw new ApplicationException(e.getMessage());
		} 
		finally 
		{
			session.close();
		}
		return adminList;
	}

	//To delete a record using admin id
	
	public void delete(int id) throws ApplicationException 
	{
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();

		try
		{

			BranchAdminEntity pojo = session.get(BranchAdminEntity.class, id);

			session.delete(pojo);

			transaction.commit();

		}
		catch (HibernateException e)
		{
			throw new ApplicationException(e.getMessage());
		}
		finally
		{
			session.close();
		}

	}

	//To add a record into the database
	
	public int addAdmin(BranchAdminPojo pojo) throws ApplicationException 
	{
		SessionFactory sf = null;
		Session session = null;
		int id = 0;

		sf = HibernateUtil.getSessionFactory();
		session = sf.openSession();
		

		Transaction transaction = session.beginTransaction();

		try 
		{
			BranchAdminEntity admin = new BranchAdminEntity();
			
			admin.setFirstName(pojo.getFirstName());
			admin.setLastName(pojo.getLastName());
			admin.setAge(pojo.getAge());
			admin.setGender(pojo.getGender());
			admin.setDob(pojo.getDob());
			admin.setContactNumber(pojo.getContactNumber());
			admin.setAlternateContactNumber(pojo.getAlternateContactNumber());
			admin.setEmailId(pojo.getEmailId());
			admin.setBranchName(pojo.getBranchName());
			admin.setAddressLine1(pojo.getAddressLine1());
			admin.setAddressLine2(pojo.getAddressLine2());
			admin.setCity(pojo.getCity());
			admin.setState(pojo.getState());
			admin.setZipCode(pojo.getZipCode());

			session.save(admin);
			
			session.getTransaction().commit();
			id = admin.getBranchAdminId();

		}
		catch (HibernateException e)
		{
			throw new ApplicationException(e.getMessage());
		}

		finally 
		{
			session.close();
		}
		return id;

	}
	
//Fetches a record by using corresponding id
	
	public BranchAdminPojo getBranchAdminId(int id) throws ApplicationException
	{    
	
		
		SessionFactory sf = null;
		Session session = null;
		sf = HibernateUtil.getSessionFactory();
		session = sf.openSession();
		List<BranchAdminPojo> adminList = new ArrayList<BranchAdminPojo>();
		BranchAdminPojo pojo = new BranchAdminPojo();
		
		try {
			List list = session.createQuery("from BranchAdminEntity  where branch_admin_id="+id+"").list();

			for (int i = 0; i < list.size(); i++) {
				BranchAdminEntity admin = (BranchAdminEntity) list.get(i);
			
				pojo.setBranchAdminId(admin.getBranchAdminId());
				pojo.setFirstName(admin.getFirstName());
				pojo.setLastName(admin.getLastName());
				pojo.setAge(admin.getAge());
				pojo.setGender(admin.getGender());
				pojo.setDob(admin.getDob());
				pojo.setContactNumber(admin.getContactNumber());
				pojo.setAlternateContactNumber(admin.getAlternateContactNumber());
				pojo.setEmailId(admin.getEmailId());
				pojo.setBranchName(admin.getBranchName());
				pojo.setAddressLine1(admin.getAddressLine1());
				pojo.setAddressLine2(admin.getAddressLine2());
				pojo.setCity(admin.getCity());
				pojo.setState(admin.getState());
				pojo.setZipCode(admin.getZipCode());
				
			}
		}
			catch (HibernateException e) 
			{
				throw new ApplicationException(e.getMessage());
			} 
			finally 
			{
				session.close();
			}
			return pojo;
		}

//Update a record in database	
	
	public  void update(BranchAdminPojo pojo) throws ApplicationException
	{
		   
	      SessionFactory sf= null;
	 	  Session session = null;
	      sf=HibernateUtil.getSessionFactory();
		  session = sf.openSession();
		  Transaction transaction=session.beginTransaction();
			
	      try 
	      {
	   
	    	    BranchAdminEntity admin = new BranchAdminEntity();
	    	    
	    	    admin.setBranchAdminId(pojo.getBranchAdminId());
	    	    admin.setFirstName(pojo.getFirstName());
				admin.setLastName(pojo.getLastName());
				admin.setAge(pojo.getAge());
				admin.setGender(pojo.getGender());
				admin.setDob(pojo.getDob());
				admin.setContactNumber(pojo.getContactNumber());
				admin.setAlternateContactNumber(pojo.getAlternateContactNumber());
				admin.setEmailId(pojo.getEmailId());
				admin.setBranchName(pojo.getBranchName());
				admin.setAddressLine1(pojo.getAddressLine1());
				admin.setAddressLine2(pojo.getAddressLine2());
				admin.setCity(pojo.getCity());
				admin.setState(pojo.getState());
				admin.setZipCode(pojo.getZipCode());
				
	            session.update(admin);
	            session.getTransaction().commit();
	    
	      }
	  	catch (HibernateException e)
			{
				throw new ApplicationException(e.getMessage());
			}

		  finally
		  {
	      session.close();
		  }

	}
	public List<StatePojo> fetchState()  throws ApplicationException
	{

		SessionFactory sf = null;
		Session session = null;
		sf = HibernateUtil.getSessionFactory();
		session = sf.openSession();
		List<StatePojo> stateList = new ArrayList<StatePojo>();
		
		
		try {
			List list = session.createQuery("from StateEntity").list();

			for (int i = 0; i < list.size(); i++) {
				StateEntity state = (StateEntity) list.get(i);
				StatePojo pojo = new StatePojo();
				
				pojo.setId(state.getId());
				pojo.setState(state.getState());
				stateList.add(pojo);
			}
		}
			catch (HibernateException e) 
			{
				throw new ApplicationException(e.getMessage());
			} 
			finally 
			{
				session.close();
			}
			return stateList;
	}


	}

