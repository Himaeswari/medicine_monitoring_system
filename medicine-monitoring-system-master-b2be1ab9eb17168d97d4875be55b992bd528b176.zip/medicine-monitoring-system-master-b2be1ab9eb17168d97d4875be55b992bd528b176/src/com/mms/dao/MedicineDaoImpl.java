package com.mms.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.stereotype.Repository;

import com.mms.model.BranchAdminPojo;
import com.mms.model.MedicinePojo;

@Repository("medicineDao")
public class MedicineDaoImpl implements MedicineDao 
{
	
//Fetching the medicine details from the database
	
public List<MedicinePojo> fetchMedicine() throws ApplicationException
{
		
		SessionFactory sf = null;
		Session session = null;
		sf = HibernateUtil.getSessionFactory();
		session = sf.openSession();
		List<MedicinePojo> medicineList = new ArrayList<MedicinePojo>();
		
		
		try
		{
			List list = session.createQuery("from MedicineEntity").list();

			for (int i = 0; i < list.size(); i++)
			{
				MedicineEntity medicine = (MedicineEntity) list.get(i);
				MedicinePojo pojo = new MedicinePojo();
				
				pojo.setMedicineId(medicine.getMedicineId());
				pojo.setMedicineDescription(medicine.getMedicineDescription());
				pojo.setCureFor(medicine.getCureFor());
				pojo.setManufacturingCompany(medicine.getManufacturingCompany());
				pojo.setDosage(medicine.getDosage());
				pojo.setPrescribedFor(medicine.getPrescribedFor());
				pojo.setStock(medicine.getStock());
				medicineList.add(pojo);
			}
		} 
		
		catch (HibernateException e) 
		{
			throw new ApplicationException(e.getMessage());
		} 
		finally 
		{
			session.close();
		}
		return medicineList;
	}

//To delete a record using medicine id
	
	public void delete(int id) throws ApplicationException 
	{
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();

		try
		{

			MedicineEntity pojo = session.get(MedicineEntity.class, id);

			session.delete(pojo);

			transaction.commit();

		}
		catch (HibernateException e)
		{
			throw new ApplicationException(e.getMessage());
		}
		finally
		{
			session.close();
		}

	}

//To add a record into the database
	
	public int addMedicine(MedicinePojo pojo) throws ApplicationException 
	{
		SessionFactory sf = null;
		Session session = null;
		int id = 0;

		sf = HibernateUtil.getSessionFactory();
		session = sf.openSession();
		

		Transaction transaction = session.beginTransaction();

		try 
		{
			MedicineEntity medicine = new MedicineEntity();
			
			medicine.setMedicineDescription(pojo.getMedicineDescription());
			medicine.setCureFor(pojo.getCureFor());
			medicine.setManufacturingCompany(pojo.getManufacturingCompany());
			medicine.setDosage(pojo.getDosage());
			medicine.setPrescribedFor(pojo.getPrescribedFor());
			medicine.setStock(pojo.getStock());
			
			session.save(medicine);
			
			session.getTransaction().commit();
			id = medicine.getMedicineId();

		}
		catch (HibernateException e)
		{
			throw new ApplicationException(e.getMessage());
		}

		finally 
		{
			session.close();
		}
		return id;

	}

//Fetches a record using corresponding medicine id
	
	public MedicinePojo getMedicineId(int id) throws ApplicationException
	{    
	
		
		SessionFactory sf = null;
		Session session = null;
		sf = HibernateUtil.getSessionFactory();
		session = sf.openSession();
		List<MedicinePojo> medicineList = new ArrayList<MedicinePojo>();
		MedicinePojo pojo = new MedicinePojo();
		
		try 
		{
			    List list = session.createQuery("from MedicineEntity  where medicine_id="+id+"").list();
			
                for (int i = 0; i < list.size(); i++)
                {
				MedicineEntity medicine = (MedicineEntity) list.get(i);
			
				pojo.setMedicineId(medicine.getMedicineId());
				pojo.setMedicineDescription(medicine.getMedicineDescription());
				pojo.setCureFor(medicine.getCureFor());
				pojo.setManufacturingCompany(medicine.getManufacturingCompany());
				pojo.setDosage(medicine.getDosage());
				pojo.setPrescribedFor(medicine.getPrescribedFor());
				pojo.setStock(medicine.getStock());
				
			}
		}
			catch (HibernateException e) 
			{
				throw new ApplicationException(e.getMessage());
			} 
			finally 
			{
				session.close();
			}
			return pojo;
		}

//Updates a record in database
	
	public  void update(MedicinePojo pojo) throws ApplicationException
	{
		   
	      SessionFactory sf= null;
	 	  Session session = null;
	      sf=HibernateUtil.getSessionFactory();
		  session = sf.openSession();
		  Transaction transaction=session.beginTransaction();
			
	      try 
	      {
	  
	    	    MedicineEntity medicine = new MedicineEntity();
	    	    
	    	    medicine.setMedicineId(pojo.getMedicineId());
	    	    medicine.setMedicineDescription(pojo.getMedicineDescription());
				medicine.setCureFor(pojo.getCureFor());
				medicine.setManufacturingCompany(pojo.getManufacturingCompany());
				medicine.setDosage(pojo.getDosage());
				medicine.setPrescribedFor(pojo.getPrescribedFor());
				medicine.setStock(pojo.getStock());
				
	 	        session.update(medicine);
	            session.getTransaction().commit();
	       
	      }
	  	catch (HibernateException e)
			{
				throw new ApplicationException(e.getMessage());
			}

		  finally
		  {
	      session.close();
		  }

	}

	


}
