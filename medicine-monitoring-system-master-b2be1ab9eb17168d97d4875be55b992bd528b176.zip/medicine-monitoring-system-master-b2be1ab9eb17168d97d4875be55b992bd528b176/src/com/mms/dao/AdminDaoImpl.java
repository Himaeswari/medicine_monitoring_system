package com.mms.dao;

import java.util.Iterator;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.stereotype.Repository;

import com.mms.model.AdminPojo;

@Repository("adminDao")
public class AdminDaoImpl implements AdminDao 
{
	
	//To authenticate Admin Id and Password	
	
	public int checkAdmin(AdminPojo pojo) throws ApplicationException
	{
		SessionFactory sf = null;
		Session session = null;
		sf = HibernateUtil.getSessionFactory();
		session = sf.openSession();
        int check = 0;

		try
		{

			List list1 = (List) session.createQuery("from AdminEntity where admin_id='" + pojo.getAdminId() + "'").list();
			Iterator iterator = list1.iterator();
			if (iterator.hasNext())
			{
				List list2 = (List) session.createQuery("from AdminEntity where password='" + pojo.getPassword() + "'").list();
				Iterator iterator1 = list2.iterator();
				if (iterator1.hasNext()) {
					check = 1;
			}
		  
		    else 
		    {
					check = 0;
			}

			} 
			else
			{
				   check = 2;
			}

		} 
		
		catch (HibernateException e)
		{
			throw new ApplicationException(e.getMessage());
		}

		finally
		{
			session.close();
		}

		return check;

	}

	//To add a record into the database
	
	public int add(AdminPojo pojo) throws ApplicationException 
	{
		SessionFactory sf = null;
		Session session = null;
		int id = 0;

		sf = HibernateUtil.getSessionFactory();
		session = sf.openSession();

		Transaction transaction = session.beginTransaction();

		try 
		{
			AdminEntity login = new AdminEntity();
			login.setFirstName(pojo.getFirstName());
			login.setLastName(pojo.getLastName());
			login.setAge(pojo.getAge());
			login.setGender(pojo.getGender());
			login.setDob(pojo.getDob());
			login.setContactNumber(pojo.getContactNumber());
			login.setAlternateContactNumber(pojo.getAlternateContactNumber());
			login.setEmailId(pojo.getEmailId());
			login.setPassword(pojo.getPassword());

			session.save(login);
			session.getTransaction().commit();
			id = login.getAdminId();
		

		} 
		catch (HibernateException e)
		{
			throw new ApplicationException(e.getMessage());
		}

		finally
		{
			session.close();
		}

		return id;
	}

}
