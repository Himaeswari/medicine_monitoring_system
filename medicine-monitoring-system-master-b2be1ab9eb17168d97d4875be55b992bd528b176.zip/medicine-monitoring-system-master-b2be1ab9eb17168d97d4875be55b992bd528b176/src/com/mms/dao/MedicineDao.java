package com.mms.dao;

import java.util.List;

import com.mms.model.BranchAdminPojo;
import com.mms.model.MedicinePojo;

public interface MedicineDao 
{
	public List<MedicinePojo> fetchMedicine() throws ApplicationException;
	public  void delete(int id) throws ApplicationException ;
	public int addMedicine(MedicinePojo pojo) throws ApplicationException;
	public void update(MedicinePojo pojo) throws ApplicationException;
	public MedicinePojo getMedicineId(int id) throws ApplicationException;
}
