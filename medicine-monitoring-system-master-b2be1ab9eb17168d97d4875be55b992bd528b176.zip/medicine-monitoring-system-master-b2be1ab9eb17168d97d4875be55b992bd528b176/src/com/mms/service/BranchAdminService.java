package com.mms.service;

import java.util.List;

import com.mms.dao.ApplicationException;
import com.mms.model.StatePojo;
import com.mms.model.BranchAdminPojo;

public interface BranchAdminService
{
	public List<BranchAdminPojo> fetchAdmin() throws ApplicationException;
	public  void delete(int id) throws ApplicationException ;
	public int addAdmin(BranchAdminPojo pojo) throws ApplicationException;
	public BranchAdminPojo getBranchAdminId(int id) throws ApplicationException;
	public void update(BranchAdminPojo bPojo) throws ApplicationException;
	public List<StatePojo> fetchState() throws ApplicationException;
}
