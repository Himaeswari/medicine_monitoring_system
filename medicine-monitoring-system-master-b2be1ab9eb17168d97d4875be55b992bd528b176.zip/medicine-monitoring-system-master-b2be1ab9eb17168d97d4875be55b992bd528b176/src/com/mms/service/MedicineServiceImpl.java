package com.mms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mms.dao.ApplicationException;
import com.mms.dao.BranchAdminDao;
import com.mms.dao.BranchAdminDaoImpl;
import com.mms.dao.MedicineDao;
import com.mms.dao.MedicineDaoImpl;
import com.mms.model.BranchAdminPojo;
import com.mms.model.MedicinePojo;

@Service("medicineService")
public class MedicineServiceImpl implements MedicineService
{
	@Autowired
	BranchAdminDao branchAdminDao;

	@Override
	public List<MedicinePojo> fetchMedicine() throws ApplicationException
	{
		MedicineDao hd = new MedicineDaoImpl();
		List medicineList = hd.fetchMedicine();

		return medicineList;
	}

	@Override
	public void delete(int id) throws ApplicationException 
	{
		MedicineDao hd = new MedicineDaoImpl();
		hd.delete(id);

	}

	@Override
	public int addMedicine(MedicinePojo pojo) throws ApplicationException
	{
		MedicineDao hd = new MedicineDaoImpl();
		int id = hd.addMedicine(pojo);
		return id;

	}
	
	@Override
	public void update(MedicinePojo pojo) throws ApplicationException
	{
		MedicineDao hd = new MedicineDaoImpl();
	    hd.update(pojo);
    }
	
	@Override
	public MedicinePojo getMedicineId(int id) throws ApplicationException 
	{
		MedicineDao hd = new MedicineDaoImpl();
	    MedicinePojo pojo=hd.getMedicineId(id);
	    return pojo;
     }
}
