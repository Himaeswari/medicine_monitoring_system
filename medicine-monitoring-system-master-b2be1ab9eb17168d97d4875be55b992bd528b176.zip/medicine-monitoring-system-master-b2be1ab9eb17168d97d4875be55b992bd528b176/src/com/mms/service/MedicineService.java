package com.mms.service;

import java.util.List;

import com.mms.dao.ApplicationException;
import com.mms.model.MedicinePojo;

public interface MedicineService 
{
	public List<MedicinePojo> fetchMedicine() throws ApplicationException;
	public  void delete(int id) throws ApplicationException ;
	public int addMedicine(MedicinePojo pojo) throws ApplicationException;
	public void update(MedicinePojo pojo) throws ApplicationException;
	public MedicinePojo getMedicineId(int id) throws ApplicationException;
}
