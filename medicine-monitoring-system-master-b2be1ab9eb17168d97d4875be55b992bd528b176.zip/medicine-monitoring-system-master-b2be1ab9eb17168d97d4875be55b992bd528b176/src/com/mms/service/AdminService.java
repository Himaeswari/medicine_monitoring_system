package com.mms.service;

import com.mms.dao.ApplicationException;
import com.mms.model.AdminPojo;

public interface AdminService 
{
	public int checkAdmin(AdminPojo pojo) throws ApplicationException;
	public int  add(AdminPojo pojo) throws ApplicationException;
}
