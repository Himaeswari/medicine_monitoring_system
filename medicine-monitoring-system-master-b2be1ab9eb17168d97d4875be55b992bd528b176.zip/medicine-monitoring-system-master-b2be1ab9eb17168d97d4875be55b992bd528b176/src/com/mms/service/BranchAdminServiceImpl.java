package com.mms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mms.dao.AdminDaoImpl;
import com.mms.dao.AdminDao;
import com.mms.dao.ApplicationException;
import com.mms.dao.BranchAdminDaoImpl;
import com.mms.dao.BranchAdminDao;
import com.mms.model.AdminPojo;
import com.mms.model.BranchAdminPojo;
import com.mms.model.StatePojo;

@Service("branchAdminService")
public class BranchAdminServiceImpl implements BranchAdminService
{
	@Autowired
	BranchAdminDao branchAdminDao;

	@Override
	public List<BranchAdminPojo> fetchAdmin() throws ApplicationException 
	{
		BranchAdminDao hd = new BranchAdminDaoImpl();
		List adminList = hd.fetchAdmin();

		return adminList;
	}

	@Override
	public void delete(int id) throws ApplicationException 
	{
		BranchAdminDao hd = new BranchAdminDaoImpl();
		hd.delete(id);

	}

	@Override
	public int addAdmin(BranchAdminPojo pojo) throws ApplicationException 
	{
		BranchAdminDao hd = new BranchAdminDaoImpl();
		int id = hd.addAdmin(pojo);
		return id;

	}
	
	@Override
	public void update(BranchAdminPojo pojo) throws ApplicationException 
	{
		BranchAdminDao hd = new BranchAdminDaoImpl();
	    hd.update(pojo);
	}
	
	@Override
	public BranchAdminPojo getBranchAdminId(int id) throws ApplicationException
	{
		BranchAdminDao hd = new BranchAdminDaoImpl();
	    BranchAdminPojo pojo=hd.getBranchAdminId(id);
	    return pojo;
}

	@Override
	public List<StatePojo> fetchState() throws ApplicationException 
	{
		BranchAdminDao hd = new BranchAdminDaoImpl();
		List stateList = hd.fetchState();

		return stateList;
	}
}
