package com.mms.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mms.dao.AdminDaoImpl;
import com.mms.dao.AdminDao;
import com.mms.dao.ApplicationException;
import com.mms.model.AdminPojo;

@Service("adminService")
public class AdminServiceImpl implements AdminService
{
	@Autowired
	AdminDao adminDao;

	@Override
	public int checkAdmin(AdminPojo pojo) throws ApplicationException 
	{
		AdminDao hd = new AdminDaoImpl();
		int result = hd.checkAdmin(pojo);

		return result;
	}

	@Override
	public int add(AdminPojo pojo) throws ApplicationException 
	{
		AdminDao hd = new AdminDaoImpl();
		int add = hd.add(pojo);
		return add;
	}

}
