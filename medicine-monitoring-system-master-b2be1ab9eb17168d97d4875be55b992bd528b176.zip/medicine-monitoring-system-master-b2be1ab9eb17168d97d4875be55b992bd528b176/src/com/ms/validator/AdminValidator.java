package com.ms.validator;

public class AdminValidator {
	public static boolean checkDigit(String integer)
    {
        boolean bool=false;
        for(int i=0;i<integer.length();i++)
        {
        	
            if(Character.isDigit(integer.charAt(i))==false)
            {
                bool=false;
                break;
            }
            else 
            {
                bool=true;
            }
        }
        return bool;
    }

}
